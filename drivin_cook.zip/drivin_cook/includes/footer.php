</main>
<footer class="bg-dark text-light mt-5 py-4">
    <div class="container text-center">
        <p>&copy; <?php echo date('Y'); ?> Driv'n Cook - Système de gestion des franchises</p>
        <p class="mb-0"><small>Développé pour la gestion des food trucks de qualité</small></p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/main.js"></script>
</body>
</html>